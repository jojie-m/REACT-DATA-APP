// Start Strapi
const strapi = require("strapi");
strapi().start();
