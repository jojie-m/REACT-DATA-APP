module.exports = {
  jwtSecret: process.env.JWT_SECRET || '8068927f-74c3-498b-875e-7ef3d342e423'
};