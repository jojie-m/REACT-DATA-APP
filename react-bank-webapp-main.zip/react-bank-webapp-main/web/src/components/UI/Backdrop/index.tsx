import React from 'react';
import './style.scss';

const Backdrop: React.FC = () => <div className="backdrop" />;

export default Backdrop;
