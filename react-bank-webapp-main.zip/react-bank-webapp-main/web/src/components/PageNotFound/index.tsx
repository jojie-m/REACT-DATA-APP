import React from 'react';

const PageNotFound = () => <h1>Error 404 - page not found</h1>;

export default PageNotFound;
